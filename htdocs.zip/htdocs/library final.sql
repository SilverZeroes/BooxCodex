-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2025 at 06:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `year` varchar(4) DEFAULT NULL,
  `description` text NOT NULL,
  `cover` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `year`, `description`, `cover`) VALUES
(1, 'The Brothers Karamazov', 'Fyodor Dostoevsky', '1880', 'Written by the Russian literary giant Fyodor Dostoevsky, The Brothers Karamazov is a profound exploration of faith, morality, and human psychology. As a philosophical novel, it examines the conflicts that arise within families and society, raising timeless questions about free will, responsibility, and the nature of good and evil. Its impact resonates across literature, philosophy, and theology, cementing Dostoevsky’s reputation as one of the greatest novelists of the 19th century.', 'book0.jpg'),
(2, 'Notes from Underground', 'Fyodor Dostoevsky', '1864', 'Fyodor Dostoevsky’s Notes from the Underground, a groundbreaking precursor to existentialist literature, erupts with the bitter, brilliant monologue of its unnamed narrator—a man rebelling against reason, progress, and society itself. This fierce, introspective novella shattered 19th-century literary conventions and paved the way for modern psychology, influencing thinkers from Nietzsche to Freud and reshaping how the world explores consciousness, freedom, and human contradiction.', 'book1.jpg'),
(3, 'Crime and Punishment', 'Fyodor Dostoevsky', '1866', 'Crime and Punishment, born from Fyodor Dostoevsky’s turbulent life and serialized in 1866, is a masterwork of psychological realism. This electrifying Russian novel plunges readers into the feverish mind of Raskolnikov, transforming literature forever with its bold exploration of guilt, redemption, and moral rebellion.', 'book2.jpg'),
(4, 'The Stranger', 'Albert Camus', '1942', 'Albert Camus’s The Stranger, a landmark of existentialist fiction, offers a stark, sun-drenched portrait of alienation through its unforgettable narrator, Meursault. Its minimalist power reshaped modern storytelling and ignited global conversations about meaning, freedom, and the absurd.', 'book3.jpg'),
(5, 'The Trial', 'Franz Kafka', '1925', 'Franz Kafka’s The Trial, published posthumously in 1925, is a haunting cornerstone of modernist literature. Its surreal tale of Josef K.’s inexplicable prosecution introduced a new vocabulary for oppression and bureaucracy, leaving an indelible mark on political thought and literary imagination.', 'book4.jpg'),
(6, 'The Road', 'Cormac McCarthy', '2006', 'Cormac McCarthy’s The Road, a Pulitzer-winning post-apocalyptic odyssey, blends poetic minimalism with raw emotion. Its father-son journey through a ruined world redefined dystopian fiction and moved readers worldwide with its fierce meditation on love, survival, and the last embers of hope.', 'book5.jpg'),
(7, 'The Lord of the Rings', 'J.R.R Tolkien', '1955', 'J.R.R. Tolkien’s The Lord of the Rings, forged from his scholarly passion for languages and myth, is the towering epic that revolutionized fantasy. Its richly imagined Middle-earth set new standards for world-building and inspired countless authors, films, and global fan cultures.', 'book6.jpg'),
(8, 'The Hobbit', 'J.R.R Tolkien', '1937', 'Tolkien’s The Hobbit began as a bedtime story and blossomed into one of literature’s most beloved adventures. This charming, fast-paced fantasy ignited the modern genre, inviting generations of readers into Middle-earth with its warmth, wit, and heroic heart.', 'book7.jpg'),
(9, 'Meditation', 'Marcus Aureilius', '170', 'Marcus Aurelius’s Meditations, written in the 2nd century as private reflections, stands as a timeless cornerstone of Stoic philosophy. Its calm, luminous wisdom has guided thinkers, leaders, and everyday readers for centuries, shaping Western ideas of virtue, resilience, and inner peace.', 'book8.jpg'),
(10, 'The Book of the New Sun', 'Gene Wolfe', '1983', 'Gene Wolfe’s The Book of the New Sun, a visionary blend of science fiction and literary allegory, is famed for its dazzling language and labyrinthine storytelling. Its enigmatic narrator Severian helped redefine speculative fiction, inspiring generations of writers with Wolfe’s intricate, puzzle-like prose.', 'book9.jpg'),
(11, 'Les Miserables', 'Victor Hugo', '1862', 'Victor Hugo’s Les Misérables, born from his fierce humanitarian vision, is one of the grand monuments of world literature. This sweeping historical drama humanized social injustice, stirring political consciousness across continents and becoming a cultural touchstone through countless adaptations.', 'book10.jpg'),
(12, '1984', 'George Orwell', '1949', 'George Orwell’s 1984 is a chilling masterpiece of dystopian fiction forged from the anxieties of totalitarianism. Its concepts—Big Brother, doublethink, thoughtcrime—became universal language, fundamentally shaping how the world understands power, surveillance, and freedom.', 'book11.jpg'),
(13, 'Lord of the Flies', 'William Golding', '1954', 'William Golding’s Lord of the Flies, a gripping allegorical novel born from postwar anxieties, exposes the fragile veneer of civilization through the descent of stranded schoolboys. Its stark vision of human nature has influenced education, psychology, and debates about society for decades.', 'book12.jpg'),
(14, 'The Grapes of Wrath', 'John Steinbeck', '1939', 'John Steinbeck’s The Grapes of Wrath, forged from the struggles of Dust Bowl migrants, is a towering American epic of resilience and justice. Blending documentary grit with lyrical power, it exposed the human cost of economic cruelty and stirred national conscience, becoming one of the most influential—and fiercely compassionate—novels of the 20th century.', 'book13.jpg'),
(15, 'Twenty Thousand Leagues Under the Sea', 'J.R.R Tolkien', '1937', 'Jules Verne’s Twenty Thousand Leagues Under the Sea, a visionary fusion of science, adventure, and mystery, introduced the iconic Captain Nemo and his marvel, the Nautilus. This pioneering science-fiction classic electrified readers with its futuristic technology and deep-sea wonders, shaping modern adventure storytelling and inspiring generations of explorers, scientists, and dreamers.', 'book14.jpg'),
(16, 'Our Mutual Friend', 'Charles Dickens', '1865', 'Charles Dickens’s Our Mutual Friend, his final completed novel, is a dazzling blend of mystery, satire, and social critique centered on a fortune built from London’s grimy riverbanks. Brimming with eccentric characters, sharp humor, and biting commentary on wealth and identity, it cemented Dickens’s legacy as a master storyteller and continues to influence modern literature with its rich tapestry of human folly and redemption.', 'book15.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `book_genres`
--

CREATE TABLE `book_genres` (
  `book_id` int(11) NOT NULL,
  `genre_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_genres`
--

INSERT INTO `book_genres` (`book_id`, `genre_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 1),
(2, 4),
(2, 6),
(3, 1),
(3, 2),
(3, 4),
(3, 5),
(3, 6),
(4, 1),
(4, 4),
(4, 7),
(5, 7),
(5, 8),
(5, 19),
(6, 4),
(6, 9),
(6, 10),
(6, 11),
(7, 4),
(7, 12),
(7, 13),
(7, 14),
(8, 1),
(8, 4),
(8, 13),
(8, 15),
(9, 16),
(9, 17),
(10, 14),
(10, 18),
(10, 19),
(11, 1),
(11, 11),
(11, 20),
(12, 19),
(12, 21),
(12, 22),
(13, 23),
(14, 1),
(14, 20),
(14, 21),
(15, 1),
(15, 18),
(16, 1),
(16, 4);

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

CREATE TABLE `genres` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `genres`
--

INSERT INTO `genres` (`id`, `name`) VALUES
(7, 'Absurdist'),
(12, 'Adventure'),
(23, 'Allegorical Fiction'),
(15, 'Children\'s Literature'),
(5, 'Crime'),
(19, 'Dystopian'),
(14, 'Epic'),
(13, 'Fantasy'),
(4, 'Fiction'),
(17, 'Historical'),
(20, 'Historical Fiction'),
(8, 'Horror'),
(1, 'Novel'),
(2, 'Philosophical'),
(16, 'Philosophy'),
(21, 'Political Fiction'),
(10, 'Post-Apocalyptic'),
(6, 'Psychological'),
(18, 'Science Fiction'),
(22, 'Social Science Fiction'),
(3, 'Theological'),
(11, 'Tragedy'),
(9, 'Western');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_genres`
--
ALTER TABLE `book_genres`
  ADD PRIMARY KEY (`book_id`,`genre_id`),
  ADD KEY `genre_id` (`genre_id`);

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `genres`
--
ALTER TABLE `genres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book_genres`
--
ALTER TABLE `book_genres`
  ADD CONSTRAINT `book_genres_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `book_genres_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
