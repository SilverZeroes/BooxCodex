<nav id="sideNav">
        <a href="/">Home</a>
        <a href="/catalog/">Catalogue</a>
        <a href="/genres/">Genres</a>
        <a href="/about/">About</a>
</nav>