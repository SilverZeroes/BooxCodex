<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="favicon" href="/favicon.ico">
    <link rel="stylesheet" href="/css/index.css">
    <script src="/scripts/script.js"></script>
    <title>BooxCodex</title>
</head>

<body>
    <?php
    include $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
    include $_SERVER['DOCUMENT_ROOT'] . '/includes/nav.php';
    ?>
    <div onclick="closeNav()" style="min-height: 100vh;">
        <section class="content" id="main" onclick="closeNav()">
            <h1>
                Contributions:
            </h1>
            <ol>
                <li>
                    Abdullah Al-Hasani: PHP setup, Book selection.
                </li>
                <li>
                    Ahmed Al-Zughaybi: Javascript.
                </li>
                <li>
                    Sami Al-Muabadi: HTML Page Structure.
                </li>
                <li>
                    Muath Al-Zaydi: MySQL setup.
                </li>
                <li>
                    Ziyad Al-Amoudi: CSS Style.
                </li>


            </ol>
        </section>
    </div>
    <?php
    include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php';
    ?>
</body>

</html>