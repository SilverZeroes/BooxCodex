/*
    JavaScript Requirements:
    ▪ Display item info on click                        - Done
    ▪ Form validation (required fields, email format)   - Done
    ▪ Slideshow for images or simple animation          - Done
*/

function openNav() {
    document.getElementById("sideNav").style.left = "0px";
    document.getElementById("main").style.marginLeft = "200px";
}

function closeNav() {
    document.getElementById("sideNav").style.left = "-160px";
    document.getElementById("main").style.marginLeft = "40px";
}