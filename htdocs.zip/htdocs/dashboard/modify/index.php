<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Record</title>
    <link rel="icon" type="favicon" href="/favicon.ico">
    <link rel="stylesheet" href="/css/index.css?v=20251120">
    <link rel="stylesheet" href="/css/catalog.css?v=20251120">
    <script src="/scripts/script.js"></script>
    <script src="/scripts/catalog.js"></script>
</head>
<body>
    
    <?php
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/nav.php';
    ?>

    <div onclick="closeNav()" style="min-height: 100vh;">
        <section class="content" id="main">
            <h1>Insert Record</h1>

            <br>
            
            <?php
            

            $genres_result = $mysqli->query("SELECT id, name FROM genres ORDER BY name ASC");

            ?>

            <?php
                // Get book ID from GET
                $book_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                if (!$book_id) die("Invalid book ID.");

                // Fetch book data
                $stmt = $mysqli->prepare("SELECT title, author, year, description FROM books WHERE id = ?");
                $stmt->bind_param("i", $book_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $book = $result->fetch_assoc();
                $stmt->close();
                if (!$book) die("Book not found.");

                // Fetch all genres
                $genres_result = $mysqli->query("SELECT id, name FROM genres ORDER BY name ASC");

                // Fetch genres currently assigned to this book
                $stmt = $mysqli->prepare("SELECT genre_id FROM book_genres WHERE book_id = ?");
                $stmt->bind_param("i", $book_id);
                $stmt->execute();
                $res = $stmt->get_result();
                $current_genres = [];
                while ($row = $res->fetch_assoc()) {
                    $current_genres[] = (int)$row['genre_id'];
                }
                $stmt->close();

                // Handle POST update
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $title = $_POST['title'] ?? '';
                    $author = $_POST['author'] ?? '';
                    $year = $_POST['year'] ?? '';
                    $description = $_POST['description'] ?? '';
                    $genres = $_POST['genres'] ?? [];

                    if (!$title || !$author || !$year || empty($genres)) die("All fields are required.");

                    $mysqli->begin_transaction();
                    try {
                        // Update book info
                        $stmt = $mysqli->prepare("UPDATE books SET title = ?, author = ?, year = ?, description = ? WHERE id = ?");
                        $stmt->bind_param("ssisi", $title, $author, $year, $description, $book_id);
                        $stmt->execute();
                        $stmt->close();

                        // Remove old genres
                        $stmt = $mysqli->prepare("DELETE FROM book_genres WHERE book_id = ?");
                        $stmt->bind_param("i", $book_id);
                        $stmt->execute();
                        $stmt->close();

                        // Insert new genres
                        $genres = array_map('intval', array_unique($genres));
                        foreach ($genres as $genre_id) {
                            $stmt = $mysqli->prepare("INSERT INTO book_genres (book_id, genre_id) VALUES (?, ?)");
                            $stmt->bind_param("ii", $book_id, $genre_id);
                            $stmt->execute();
                            $stmt->close();
                        }

                        $mysqli->commit();

                        echo "Book updated successfully.";
                        // Optionally redirect to avoid resubmission
                        header("Location: /dashboard/");
                        exit;

                    } catch (Exception $e) {
                        $mysqli->rollback();
                        echo "Error: " . h($e->getMessage());
                    }
                }
                ?>

            <form action="" method="post">
                <label>Title:</label>
                <input type="text" name="title" value="<?= h($book['title']) ?>" required><br>

                <label>Author:</label>
                <input type="text" name="author" value="<?= h($book['author']) ?>" required><br>

                <label>Year:</label>
                <input type="number" name="year" value="<?= h($book['year']) ?>" required><br>

                <label>Description:</label><br>
                <textarea name="description" rows="4" cols="50"><?= h($book['description']) ?></textarea><br>

                <label>Genres:</label><br>
                <?php while ($row = $genres_result->fetch_assoc()): ?>
                    <input type="checkbox" name="genres[]" value="<?= h($row['id']) ?>" 
                        id="genre<?= h($row['id']) ?>" 
                        <?= in_array($row['id'], $current_genres) ? 'checked' : '' ?>>
                    <label for="genre<?= h($row['id']) ?>"><?= h($row['name']) ?></label><br>
                <?php endwhile; ?><br>

                <button type="submit">Update Book</button>
            </form>

        </section>
    </div>


    <?php 
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; 
    ?>

</body>
</html>