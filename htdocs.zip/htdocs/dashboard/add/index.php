<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Record</title>
    <link rel="icon" type="favicon" href="/favicon.ico">
    <link rel="stylesheet" href="/css/index.css?v=20251120">
    <link rel="stylesheet" href="/css/catalog.css?v=20251120">
    <script src="/scripts/script.js"></script>
    <script src="/scripts/catalog.js"></script>
</head>
<body>
    
    <?php
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/nav.php';
    ?>

    <div onclick="closeNav()" style="min-height: 100vh;">
        <section class="content" id="main">
            <h1>Insert Record</h1>

            <br>
            
            <?php
            

            $genres_result = $mysqli->query("SELECT id, name FROM genres ORDER BY name ASC");
            ?>
            <form action="/dashboard/add/" method="post">

                <label>Title:</label>
                <input type="text" name="title" required><br>

                <label>Author:</label>
                <input type="text" name="author" required><br>

                <label>Year:</label>
                <input type="number" name="year" required><br>

                <label>Description:</label><br>
                <textarea name="description" rows="4" cols="50"></textarea><br>

                <label>Genres:</label><br>
                <?php while ($row = $genres_result->fetch_assoc()): ?>
                    <input type="checkbox" name="genres[]" value="<?= h($row['id']) ?>" id="genre<?= h($row['id']) ?>">
                    <label for="genre<?= h($row['id']) ?>"><?= h($row['name']) ?></label><br>
                <?php endwhile; ?><br>

                <button type="submit">Add Book</button>
            </form>

            <?php

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $author = $_POST['author'] ?? '';
    $year = $_POST['year'] ?? '';
    $description = $_POST['description'] ?? '';
    $genres = $_POST['genres'] ?? [];

    if (!$title || !$author || !$year || empty($genres)) {
        die("All fields are required.");
    }

    $mysqli->begin_transaction();

    try {

        // Insert book including description and cover path placeholder
        $stmt = $mysqli->prepare("INSERT INTO books (title, author, year, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $title, $author, $year, $description);
        $stmt->execute();
        $book_id = $stmt->insert_id;
        $stmt->close();


        // Insert genres
        $genres = array_map('intval', array_unique($genres));
        foreach ($genres as $genre_id) {
            $stmt3 = $mysqli->prepare("INSERT INTO book_genres (book_id, genre_id) VALUES (?, ?)");
            $stmt3->bind_param("ii", $book_id, $genre_id);
            $stmt3->execute();
            $stmt3->close();
        }

        $mysqli->commit();

        // Clear POST after submission
        //header("Location: " . $_SERVER['REQUEST_URI']);
        exit;

    } catch (Exception $e) {
        $mysqli->rollback();
        echo "Error: " . h($e->getMessage());
    }
}

            ?>
        </section>
    </div>


    <?php 
        include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php'; 
    ?>

</body>
</html>