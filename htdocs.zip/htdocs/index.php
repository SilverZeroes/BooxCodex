<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="favicon" href="/favicon.ico">
    <link rel="stylesheet" href="/css/index.css?v=20251120">
    <link rel="stylesheet" href="/css/slideshow.css">

    <title>BooxCodex</title>
</head>

<body>
    <?php
    /*
        PHP & Database Requirements:
        ▪ MySQL with 15+ records                                    - Done
        ▪ At least 3 fields per item (id, name, description)        - Done
        ▪ Support insert, update, delete functionality.             - Done
        ▪ Display data on dashboard.php                             - Done
        ▪ Simple search function                                    - Done
    */

    include $_SERVER['DOCUMENT_ROOT'] . '/includes/header.php';
    include $_SERVER['DOCUMENT_ROOT'] . '/includes/nav.php';
    ?>

    <div onclick="closeNav()" style="min-height: 100vh;">

        <section class="content" id="main" onclick="closeNav()">
            <!-- Slideshow container -->
            <div class="slideshow-container">

                <!-- Full-width images with number and caption text -->
                <div class="mySlides fade">
                    <div class="numbertext">1 / 3</div>
                    <img src="/img/img1.jpg" style="width:100%">
                    <div class="text">"Where ideas live."</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">2 / 3</div>
                    <img src="/img/img2.jpg" style="width:100%">
                    <div class="text">Your gateway to knowledge, inspiration, and stories.</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">3 / 3</div>
                    <img src="/img/img3.jpg" style="width:100%">
                    <div class="text">Discover your next read—curated for curious minds</div>
                </div>

                <!-- Next and previous buttons -->
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>
            <br>

            <!-- The dots/circles -->
            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
            </div>
            <h1>
                Welcome to our humble library!
            </h1>
            <img src="/img/logo.svg" alt="logo.svg" height="200px"
                style="float: inline-end; margin: 50px; margin-right: 200px;">
            <p>
                From the moment the first words were etched onto clay tablets and inked onto parchment, books have stood
                as humanity’s most enduring vessel of knowledge, imagination, and emotion. They have carried stories
                across centuries, preserved the wisdom of generations, and allowed readers to experience countless
                worlds beyond their own. In every era, books have remained a timeless medium — not just repositories of
                information, but bridges connecting minds and hearts across distance and time. Whether bound in leather,
                printed on paper, or displayed on glowing screens, the essence of a book endures: the power to inspire,
                to teach, and to transport. At BooxCodex, we celebrate that enduring magic. Our community welcomes every
                book lover — the curious, the collectors, and the dreamers — to explore, share, and revel in the
                boundless world of books together.
                <br>
                At BooxCodex, we’re more than just a place to find books — we’re a thriving reading community built by
                and for people who love the written word. Here, stories don’t end on the last page; they continue in
                conversations, recommendations, and friendships sparked by shared passions. Members can explore curated
                reading lists, join lively discussions, and connect with others who understand the joy of getting lost
                in a good book at 2 a.m. Whether you’re diving into timeless classics, exploring emerging authors, or
                seeking a cozy corner of the internet where readers truly belong, BooxCodex offers a welcoming space to
                read, reflect, and grow together. It’s not just about collecting books — it’s about celebrating the
                people and experiences that bring them to life.
            </p>
        </section>

        <script src="/scripts/script.js"></script>
        <script src="/scripts/slideshow.js"></script>
    </div>

    <?php
    include $_SERVER['DOCUMENT_ROOT'] . '/includes/footer.php';
    ?>
</body>

</html>